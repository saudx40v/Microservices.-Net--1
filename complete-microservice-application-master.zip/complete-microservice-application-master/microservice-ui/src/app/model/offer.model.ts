export class Offer {
    constructor(
        public productId?: number,
        public discountOffer?: number
    ) {}
}