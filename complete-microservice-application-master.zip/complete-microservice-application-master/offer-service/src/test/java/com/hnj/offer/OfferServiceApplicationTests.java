//package com.hnj.offer;
//
//import org.junit.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class OfferServiceApplicationTests {
//
//    @Test
//    void contextLoads() {
//    }
//
//}
